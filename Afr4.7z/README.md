                SC BY AFR TEAM
          Created on: 30 Januari 2025

Thanks To:
• Allah SWT
• Orang tua
• Penyedia base sc dkk
• Penyedia module
• Penyedia apikey dkk
• Yt Review
• Team AFR (recode)
• Pengguna sc ini
• Dan semua yang support KAMI

<-- [ note ] -->
# base ori = https://github.com/TanakaDomp/Lilychanj-Script
# yt review = DIOLHOST
# maaf banget yang ga aku sebut, soalnya aku orang awam jadi ga kenal siapa siapa.. tapi aku tinggalin credit web base sama api. 
# dkk = dan kawan kawan
# yang di enc dilarang dijual. karna ini sc gratis. 


T E R I M A   K A S I H 
    U N T U K   S E M U A N Y A
    
• Saluran update sc ini:
https://whatsapp.com/channel/0029Vajf99IKbYMLNn7qKS3i

• Nomor untuk melaporkan atau request fitur:
wa.me/6283182419578 (raven)

berteman? chat sajaa, aku butuh temann:)) 